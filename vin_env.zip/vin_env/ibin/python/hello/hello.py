for i in range(1,22):
    print(i)