def hamza()

    puts("hello hamza")

end
